﻿Imports System.Data.OleDb
Public Class Pembelian
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim rd As OleDbDataReader
    Dim dr As OleDbDataReader
    Dim query As String = ""
    Dim query1 As String = ""
    Dim query2 As String = ""
    Dim query3 As String = ""
    Dim total As Integer = 0
    Dim tinggi As Double = 0
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Pembelian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox10.Text = Format(Now, "dd MMMM yyyy ")
        TextBox16.Text = Format(Now, "MMMM")
        
        tampil()
        autokode()

        DataGridView1.Columns(2).DefaultCellStyle.Format = "#,###"
        DataGridView1.Columns(3).DefaultCellStyle.Format = "#,###"
        
        'DataGridView2.Columns(7).DefaultCellStyle.Format = "#,###"
        'Dim cmd As OleDbCommand
        'query3 = "SELECT MAX(Kode_Transaksi) from Pembelian"
        'conn.Open()
        'cmd = New OleDbCommand(query3, conn)
        'dr = cmd.ExecuteReader
        'If dr.HasRows Then
        '    dr.Read()
        '    If dr(0) Is DBNull.Value Then
        '        TextBox1.Text = 1
        '    ElseIf dr(0) > 0 Then
        '        TextBox1.Text = dr(0) + 1
        '    End If
        'End If
        conn.Close()
    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select Kode_BarangMentah,Nama_Barang,Harga,Stock from BarangMentah"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "BarangMentah")
        DataGridView1.DataSource = ds.Tables("BarangMentah")



    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from Pembelian order by Kode_Transaksi desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        If Not dr.HasRows Then
            TextBox1.Text = "TB" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Kode_Transaksi").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "TB000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "TB000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "TB000" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Searching_Supplier.Show()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox9.Clear()
        TextBox11.Clear()
        TextBox14.Clear()
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        Dim f As Integer
        If TextBox8.Text = "" Or Not IsNumeric(TextBox8.Text) Then
            Exit Sub
        End If
        f = TextBox8.Text
        TextBox8.Text = Format(f, " ##,##0")
        TextBox8.SelectionStart = Len(TextBox8.Text)
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        autokode()
        Dim subtotal As Integer
        subtotal = TextBox7.Text * TextBox9.Text
        TextBox11.Text = subtotal
        total = total + subtotal
        TextBox8.Text = total
        Dim stockada As Integer

        Dim cmd As OleDbCommand
        query1 = "SELECT * FROM BarangMentah WHERE Kode_BarangMentah='" & TextBox5.Text & "' and Nama_Barang='" & TextBox6.Text & "'"
        conn.Open()
        cmd = New OleDbCommand(query1, conn)
        rd = cmd.ExecuteReader
        rd.Read()
        stockada = rd(2)
        Dim sisastock As Integer = stockada + TextBox9.Text
        conn.Close()
        '---------------------------------------------------------------------------------------------------------------------------------------'
        Dim cmd1 As OleDbCommand
        query2 = "update BarangMentah set Stock=" & sisastock & " WHERE Kode_BarangMentah='" & TextBox5.Text & "' and Nama_Barang='" & TextBox6.Text & "'"
        conn.Open()
        cmd1 = New OleDbCommand(query2, conn)
        cmd1.ExecuteNonQuery()
        tampil()
        conn.Close()

        '---------------------------------------------------------------------------------------------------------------------------------------'
        Dim command As OleDbCommand
        query = "insert into Pembelian(Kode_Transaksi,Tanggal,Kode_Supplier,Nama_Supplier,No_Telp,Kode_Barang,Nama_Barang,Jumlah,Harga,Subtotal,Bulan) values ( '" & TextBox1.Text & "','" & TextBox10.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "'," & TextBox7.Text & "," & TextBox9.Text & "," & TextBox11.Text & ",'" & TextBox16.Text & "')"
        conn.Open()
        command = New OleDbCommand(query, conn)
        command.ExecuteNonQuery()
        conn.Close()

        Dim input As Integer = DataGridView2.Rows.Add()
        DataGridView2.Rows(input).Cells(0).Value = TextBox1.Text
        DataGridView2.Rows(input).Cells(1).Value = TextBox2.Text
        DataGridView2.Rows(input).Cells(2).Value = TextBox3.Text
        DataGridView2.Rows(input).Cells(3).Value = TextBox4.Text
        DataGridView2.Rows(input).Cells(4).Value = TextBox5.Text
        DataGridView2.Rows(input).Cells(5).Value = TextBox6.Text
        DataGridView2.Rows(input).Cells(6).Value = TextBox9.Text
        DataGridView2.Rows(input).Cells(7).Value = TextBox7.Text
        DataGridView2.Rows(input).Cells(8).Value = TextBox11.Text

        MsgBox(DataGridView2.Rows(input).Cells(8).Value)
        'DataGridView2.Columns(7).DefaultCellStyle.Format = "#,###"
        'DataGridView2.Columns(8).DefaultCellStyle.Format = "#,###"

        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox9.Clear()
        TextBox14.Clear()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        tinggi = 0
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Dim myfont As New Font("arial", 15, FontStyle.Bold)
        Dim myfont1 As New Font("arial", 15, FontStyle.Regular)
        Dim myfont2 As New Font("arial", 20, FontStyle.Regular)
        Dim myfont3 As New Font("arial", 12, FontStyle.Regular)

        tinggi += 20
        e.Graphics.DrawString("                                              PT Vehandra Anugrah Sejahtera", myfont, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("                   Perum Taman Harapan Baru Blok M2 No. 2, Satria Kota Bekasi", myfont, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("                                             No Telphone (021-88978043)", myfont, Brushes.Black, 2, tinggi)


        tinggi += 60
        e.Graphics.DrawString("                                                       NOTA PEMBELIAN", myfont, Brushes.Black, 2, tinggi)
        'memeriksa jika masih ada baris tersisa

        tinggi += 60
        'DataGridView2.Item(0, DataGridView2.CurrentCell.RowIndex).Value
        e.Graphics.DrawString(" No.Nota =" & TextBox1.Text & "                                                                      Date=" & TextBox10.Text, myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString(" Kode Customer    : " & TextBox2.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Nama Customer   : " & TextBox3.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Alamat Customer  : " & TextBox4.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" No Telphone          : " & TextBox4.Text, myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Kode          Nama Barang                                  Jumlah         Harga                  Subtotal", myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)


        For baris As Integer = 0 To DataGridView2.RowCount - 2
            tinggi += 30
            e.Graphics.DrawString(DataGridView2.Rows(baris).Cells(4).Value.ToString, myfont1, Brushes.Black, 4, tinggi)
            e.Graphics.DrawString(DataGridView2.Rows(baris).Cells(5).Value.ToString, myfont1, Brushes.Black, 150, tinggi)
            e.Graphics.DrawString(DataGridView2.Rows(baris).Cells(6).Value.ToString, myfont1, Brushes.Black, 450, tinggi)
            e.Graphics.DrawString(DataGridView2.Rows(baris).Cells(7).Value.ToString, myfont1, Brushes.Black, 570, tinggi)
            e.Graphics.DrawString(DataGridView2.Rows(baris).Cells(8).Value.ToString, myfont1, Brushes.Black, 750, tinggi)
        Next

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("                                                                                                 Total         :Rp. " & TextBox8.Text, myfont1, Brushes.Black, 2, tinggi)


        tinggi += 70
        e.Graphics.DrawString("                                                                                                      Hormat Kami", myfont1, Brushes.Black, 2, tinggi)

        tinggi += 100
        e.Graphics.DrawString("                                                                                                                   PT Vehandra Anugrah Sejahtera", myfont3, Brushes.Black, 2, tinggi)

    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        TextBox5.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        TextBox6.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        TextBox7.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        TextBox14.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
    End Sub
End Class