﻿Imports System.Data.OleDb
Public Class Master_Barang_Mentah
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Master_Barang_Mentah_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DatabaseDataSet.BarangMentah' table. You can move, or remove it, as needed.
        tampil()
        DataGridView2.Columns(2).DefaultCellStyle.Format = "#,###"
        DataGridView2.Columns(4).DefaultCellStyle.Format = "#,###"
        autokode()
        Me.DataGridView2.Columns(0).Width = 120
        Me.DataGridView2.Columns(1).Width = 150
        Me.DataGridView2.Columns(2).Width = 90
        Me.DataGridView2.Columns(3).Width = 120
        Me.DataGridView2.Columns(4).Width = 90

        Me.DataGridView2.Columns(0).HeaderText = "Kode Barang Mentah"
        Me.DataGridView2.Columns(1).HeaderText = "Nama Barang"
        Me.DataGridView2.Columns(2).HeaderText = "Stock"
        Me.DataGridView2.Columns(3).HeaderText = "Jenis Barang"
        Me.DataGridView2.Columns(4).HeaderText = "Harga"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Kode Barang Mentah Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Nama Barang Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("Stock Barang Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf ComboBox1.Text = "" Then
            MsgBox("Jenis Barang Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf TextBox4.Text = "" Then
            MsgBox("Harga Masih Kosong", vbCritical, "Salah")
            TextBox4.Focus()
        Else
            'Try
            Dim command As OleDbCommand
            query = "insert into BarangMentah values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "'," & TextBox4.Text & ")"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            MsgBox("Insert anda berhasil")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            conn.Close()
            autokode()
            ' Catch ex As Exception
            'MsgBox("Data barang mentah gagal disimpan")
            'End Try
        End If
    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from BarangMentah"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "BarangMentah")
        DataGridView2.DataSource = ds.Tables("BarangMentah")

    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from BarangMentah order by Kode_BarangMentah desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        If Not dr.HasRows Then
            TextBox1.Text = "BM" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Kode_BarangMentah").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "BM000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "BM00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "BM0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim command As OleDbCommand
            query = "update BarangMentah set Nama_Barang='" & TextBox2.Text & "', Stock=" & TextBox3.Text & ", Jenis_Barang='" & ComboBox1.Text & "', Harga=" & TextBox4.Text & " where Kode_BarangMentah = '" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            MsgBox("Update anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data barang mentah gagal diupdate")
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.ReadOnly = False
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim command As OleDbCommand
            query = "delete from BarangMentah  where Kode_BarangMentah ='" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            MsgBox("Delete anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data barang mentah gagal didelete")
        End Try
    End Sub


    Private Sub DataGridView2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView2.CellMouseClick
        With DataGridView2
            TextBox1.ReadOnly = True
            TextBox1.Text = DataGridView2.Item(0, DataGridView2.CurrentCell.RowIndex).Value
            TextBox2.Text = DataGridView2.Item(1, DataGridView2.CurrentCell.RowIndex).Value
            TextBox3.Text = DataGridView2.Item(2, DataGridView2.CurrentCell.RowIndex).Value
            ComboBox1.Text = DataGridView2.Item(3, DataGridView2.CurrentCell.RowIndex).Value
            TextBox4.Text = DataGridView2.Item(4, DataGridView2.CurrentCell.RowIndex).Value
        End With
    End Sub
End Class