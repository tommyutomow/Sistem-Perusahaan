﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Menu_Produksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.InputProduksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangMentahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangProduksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanStockBarangMentahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanStockBarangProduksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InputProduksiToolStripMenuItem, Me.ExitToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1264, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'InputProduksiToolStripMenuItem
        '
        Me.InputProduksiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BarangMentahToolStripMenuItem, Me.BarangProduksiToolStripMenuItem})
        Me.InputProduksiToolStripMenuItem.Name = "InputProduksiToolStripMenuItem"
        Me.InputProduksiToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.InputProduksiToolStripMenuItem.Text = "Input Produksi"
        '
        'BarangMentahToolStripMenuItem
        '
        Me.BarangMentahToolStripMenuItem.Name = "BarangMentahToolStripMenuItem"
        Me.BarangMentahToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.BarangMentahToolStripMenuItem.Text = "Barang Mentah"
        '
        'BarangProduksiToolStripMenuItem
        '
        Me.BarangProduksiToolStripMenuItem.Name = "BarangProduksiToolStripMenuItem"
        Me.BarangProduksiToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.BarangProduksiToolStripMenuItem.Text = "Barang Produksi"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanStockBarangMentahToolStripMenuItem, Me.LaporanStockBarangProduksiToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.ExitToolStripMenuItem.Text = "Laporan"
        '
        'LaporanStockBarangMentahToolStripMenuItem
        '
        Me.LaporanStockBarangMentahToolStripMenuItem.Name = "LaporanStockBarangMentahToolStripMenuItem"
        Me.LaporanStockBarangMentahToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanStockBarangMentahToolStripMenuItem.Text = "Laporan Stock Barang Mentah"
        '
        'LaporanStockBarangProduksiToolStripMenuItem
        '
        Me.LaporanStockBarangProduksiToolStripMenuItem.Name = "LaporanStockBarangProduksiToolStripMenuItem"
        Me.LaporanStockBarangProduksiToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanStockBarangProduksiToolStripMenuItem.Text = "Laporan Stock Barang Produksi"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label1.Font = New System.Drawing.Font("Arial", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(264, 319)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(737, 45)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "PT. VEHANDRA ANUGRAH SEJAHTERA"
        '
        'Main_Menu_Produksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 682)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main_Menu_Produksi"
        Me.Text = "Main Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents InputProduksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanStockBarangMentahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanStockBarangProduksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangMentahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangProduksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
