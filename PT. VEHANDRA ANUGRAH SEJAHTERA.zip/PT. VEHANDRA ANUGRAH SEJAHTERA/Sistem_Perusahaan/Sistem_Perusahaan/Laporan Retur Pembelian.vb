﻿Public Class Laporan_Retur_Pembelian

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim CR As New LaporanPembelian
        CrystalReportViewer1.SelectionFormula = "{ReturPembelian.Bulan} in '" & ComboBox1.Text & "' to '" & ComboBox2.Text & "'"

        CrystalReportViewer1.ReportSource = CR
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Laporan_Retur_Pembelian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class