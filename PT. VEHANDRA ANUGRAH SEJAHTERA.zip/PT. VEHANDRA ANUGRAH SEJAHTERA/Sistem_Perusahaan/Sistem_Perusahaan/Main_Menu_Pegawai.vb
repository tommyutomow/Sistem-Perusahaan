﻿Public Class Main_Menu_Pegawai

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub PembelianToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PembelianToolStripMenuItem1.Click
        ReturPembelian.MdiParent = Me
        ReturPembelian.Show()
        Label1.Visible = False
    End Sub

    Private Sub PenjualanToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem1.Click
        Retur_Penjualan.MdiParent = Me
        Retur_Penjualan.Show()
        Label1.Visible = False
    End Sub

    Private Sub PembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PembelianToolStripMenuItem.Click
        Pembelian.MdiParent = Me
        Pembelian.Show()
        Label1.Visible = False
    End Sub

    Private Sub PenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem.Click
        Penjualan.MdiParent = Me
        Penjualan.Show()
        Label1.Visible = False
    End Sub

    Private Sub Main_Menu_Pegawai_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class