﻿Imports System.Data.OleDb
Public Class Searching
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Searching_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tampil()
    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from Customer"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Customer")
        DataGridView1.DataSource = ds.Tables("Customer")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Penjualan.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox4.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox15.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox10.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox11.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        ds = New DataSet
        ds.Clear()
        query = "select * from Customer where Nama_Perusahaan like '%" & TextBox1.Text & "%'"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Item")
        DataGridView1.DataSource = ds.Tables("Item")
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        Penjualan.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox4.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        Penjualan.TextBox15.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox10.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox11.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
    End Sub
End Class