﻿Public Class Main_Menu
    Private Sub Menu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.LayoutMdi(MdiLayout.Cascade)
        Label1.Visible = True
    End Sub

    Private Sub MasterCustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterCustomerToolStripMenuItem.Click
        Master_Customer.MdiParent = Me
        Master_Customer.Show()
        Label1.Visible = False
    End Sub

    Private Sub MasterPengawaiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterPengawaiToolStripMenuItem.Click
        Master_Pengawai.MdiParent = Me
        Master_Pengawai.Show()
        Label1.Visible = False
    End Sub
    Private Sub MasterSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterSupplierToolStripMenuItem.Click
        Master_Supplier.MdiParent = Me
        Master_Supplier.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangMentahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangMentahToolStripMenuItem.Click
        Master_Barang_Mentah.MdiParent = Me
        Master_Barang_Mentah.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangProduksiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangProduksiToolStripMenuItem.Click
        Master_Barang_Produksi.MdiParent = Me
        Master_Barang_Produksi.Show()
        Label1.Visible = False
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub PenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem.Click
        Penjualan.MdiParent = Me
        Penjualan.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangProduksiToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangProduksiToolStripMenuItem1.Click
        Input_Stock_Barang_Produksi.MdiParent = Me
        Input_Stock_Barang_Produksi.Show()
        Label1.Visible = False
    End Sub

    Private Sub PenjualanToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem2.Click
        Retur_Penjualan.MdiParent = Me
        Retur_Penjualan.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanStockBarangToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanStockBarangToolStripMenuItem.Click
        Laporan_Stock_Barang_Produksi.MdiParent = Me
        Laporan_Stock_Barang_Produksi.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanPenjualanToolStripMenuItem.Click
        Laporan_Penjualan.MdiParent = Me
        Laporan_Penjualan.Show()
        Label1.Visible = False
    End Sub

    Private Sub PembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PembelianToolStripMenuItem.Click
        Pembelian.MdiParent = Me
        Pembelian.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangMentahToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangMentahToolStripMenuItem1.Click
        Input_Stock_Barang_Mentah.MdiParent = Me
        Input_Stock_Barang_Mentah.Show()
        Label1.Visible = False
    End Sub


    Private Sub PembelianToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PembelianToolStripMenuItem1.Click
        ReturPembelian.MdiParent = Me
        ReturPembelian.Show()
        Label1.Visible = False

    End Sub

    Private Sub LaporanPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanPembelianToolStripMenuItem.Click
        Laporan_Pembelian.MdiParent = Me
        Laporan_Pembelian.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanStockMentahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanStockMentahToolStripMenuItem.Click
        Laporan_Stock_Barang_Mentah.MdiParent = Me
        Laporan_Stock_Barang_Mentah.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanReturPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanReturPembelianToolStripMenuItem.Click
        Laporan_Retur_Pembelian.MdiParent = Me
        Laporan_Retur_Pembelian.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanReturPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanReturPenjualanToolStripMenuItem.Click
        Laporan_Retur_Penjualan.MdiParent = Me
        Laporan_Retur_Penjualan.Show()
        Label1.Visible = False
    End Sub
End Class