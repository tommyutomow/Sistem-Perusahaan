﻿Public Class Main_Menu_Produksi

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub LaporanStockBarangMentahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanStockBarangMentahToolStripMenuItem.Click
        Laporan_Stock_Barang_Mentah.MdiParent = Me
        Laporan_Stock_Barang_Mentah.Show()
        Label1.Visible = False
    End Sub

    Private Sub LaporanStockBarangProduksiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanStockBarangProduksiToolStripMenuItem.Click
        Laporan_Stock_Barang_Produksi.MdiParent = Me
        Laporan_Stock_Barang_Produksi.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangMentahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangMentahToolStripMenuItem.Click
        Input_Stock_Barang_Mentah.MdiParent = Me
        Input_Stock_Barang_Mentah.Show()
        Label1.Visible = False
    End Sub

    Private Sub BarangProduksiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BarangProduksiToolStripMenuItem.Click
        Laporan_Stock_Barang_Produksi.MdiParent = Me
        Laporan_Stock_Barang_Produksi.Show()
        Label1.Visible = False
    End Sub

    Private Sub Main_Menu_Produksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class