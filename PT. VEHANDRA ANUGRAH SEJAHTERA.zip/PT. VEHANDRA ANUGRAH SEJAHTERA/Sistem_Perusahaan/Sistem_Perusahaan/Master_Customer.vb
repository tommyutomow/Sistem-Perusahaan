﻿Imports System.Data.OleDb
Public Class Master_Customer
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Master_Customer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DatabaseDataSet3.Customer' table. You can move, or remove it, as needed.
        tampil()
        autokode()
        Me.DataGridView1.Columns(0).Width = 70
        Me.DataGridView1.Columns(1).Width = 120
        Me.DataGridView1.Columns(2).Width = 150
        Me.DataGridView1.Columns(3).Width = 70
        Me.DataGridView1.Columns(4).Width = 70
        Me.DataGridView1.Columns(5).Width = 120

        Me.DataGridView1.Columns(0).HeaderText = "Kode Perusahaan"
        Me.DataGridView1.Columns(1).HeaderText = "Nama Perusahaan"
        Me.DataGridView1.Columns(2).HeaderText = "Alamat"
        Me.DataGridView1.Columns(3).HeaderText = "No Telphone"
        Me.DataGridView1.Columns(4).HeaderText = "Fax"
        Me.DataGridView1.Columns(5).HeaderText = "Email"

    End Sub

   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Kode Customer Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Nama Perusahaan Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("Alamat Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf TextBox4.Text = "" Then
            MsgBox("No telp Masih Kosong", vbCritical, "Salah")
            TextBox4.Focus()
        ElseIf TextBox5.Text = "" Then
            MsgBox("Fax Masih Kosong", vbCritical, "Salah")
            TextBox5.Focus()
        ElseIf TextBox6.Text = "" Then
            MsgBox("Email Masih Kosong", vbCritical, "Salah")
            TextBox6.Focus()
        Else
            Try
                Dim command As OleDbCommand
                query = "insert into Customer values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "')"
                conn.Open()
                command = New OleDbCommand(query, conn)
                command.ExecuteNonQuery()
                tampil()
                MsgBox("Insert anda berhasil")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                TextBox5.Clear()
                TextBox6.Clear()
                conn.Close()
                autokode()
            Catch ex As Exception
                MsgBox("Data customer gagal disimpan")
            End Try
        End If
    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from Customer"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Customer")
        DataGridView1.DataSource = ds.Tables("Customer")

    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from Customer order by Kode_Perusahaan desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()


        If Not dr.HasRows Then
            TextBox1.Text = "CU" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Kode_Perusahaan").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "CU000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "CU00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "CU0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim command As OleDbCommand
            query = "update Customer set Nama_Perusahaan='" & TextBox2.Text & "', Alamat='" & TextBox3.Text & "', No_Telp='" & TextBox4.Text & "', FAX='" & TextBox5.Text & "', Email= '" & TextBox6.Text & "' where Kode_Perusahaan = '" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            MsgBox("Update anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data customer gagal diupdate")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim command As OleDbCommand
            query = "delete from Customer where Kode_Perusahaan ='" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            MsgBox("Delete anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data customer gagal didelete")
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.ReadOnly = False
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        TextBox1.ReadOnly = True
        TextBox1.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        TextBox2.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        TextBox3.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        TextBox4.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value
        TextBox5.Text = DataGridView1.Item(4, DataGridView1.CurrentCell.RowIndex).Value
        TextBox6.Text = DataGridView1.Item(5, DataGridView1.CurrentCell.RowIndex).Value
    End Sub
End Class