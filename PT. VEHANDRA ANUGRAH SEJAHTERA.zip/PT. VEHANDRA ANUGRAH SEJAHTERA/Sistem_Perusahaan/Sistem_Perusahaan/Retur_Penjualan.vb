﻿Imports System.Data.OleDb
Public Class Retur_Penjualan
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim rd As OleDbDataReader
    Dim dr As OleDbDataReader
    Dim query As String = ""
    Dim query1 As String = ""
    Dim query2 As String = ""
    Dim query3 As String = ""
    Dim tinggi As Double = 0
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"
    Private Sub Retur_Penjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox4.Text = Format(Now, "dd MMMM yyyy ")
        TextBox16.Text = Format(Now, "MMMM")
        autokode()
        'Dim cmd As OleDbCommand
        'query3 = "SELECT MAX(No_Retur) from ReturPenjualan"
        'conn.Open()
        'cmd = New OleDbCommand(query3, conn)
        'dr = cmd.ExecuteReader
        'If dr.HasRows Then
        '    dr.Read()
        '    If dr(0) Is DBNull.Value Then
        '        TextBox1.Text = 1
        '    ElseIf dr(0) > 0 Then
        '        TextBox1.Text = dr(0) + 1
        '    End If
        'End If
        'conn.Close()

    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from ReturPenjualan order by No_Retur desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()


        If Not dr.HasRows Then
            TextBox1.Text = "RJ" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("No_Retur").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "RJ000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "RJ00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "RJ0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Searching.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Searching_barangprod.Show()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox9.Clear()
        TextBox8.Clear()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If TextBox1.Text = "" Then
            MsgBox("No Retur Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Kode Customer Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("Nama Customer Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf TextBox5.Text = "" Then
            MsgBox("KodeBarang Masih Kosong", vbCritical, "Salah")
            TextBox5.Focus()
        ElseIf TextBox6.Text = "" Then
            MsgBox("NamaBarang Masih Kosong", vbCritical, "Salah")
            TextBox6.Focus()
        ElseIf TextBox7.Text = "" Then
            MsgBox("Harga Masih Kosong", vbCritical, "Salah")
            TextBox7.Focus()
        ElseIf TextBox9.Text = "" Then
            MsgBox("Jumlah Barang Masih Kosong", vbCritical, "Salah")
            TextBox9.Focus()
        ElseIf TextBox8.Text = "" Then
            MsgBox("Keterangan Masih Kosong", vbCritical, "Salah")
            TextBox8.Focus()
        Else
            Try
                Dim command As OleDbCommand
                query = "insert into ReturPenjualan(No_Retur,Tanggal,Kode_Customer,Nama_Customer,Kode_Barang,Nama_Barang,Harga,Jumlah,Keterangan,Bulan) values ( '" & TextBox1.Text & "','" & TextBox4.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "'," & TextBox7.Text & "," & TextBox9.Text & ",'" & TextBox8.Text & "','" & TextBox16.Text & "')"
                conn.Open()
                command = New OleDbCommand(query, conn)
                command.ExecuteNonQuery()
                conn.Close()
                autokode()
                Dim input As Integer = DataGridView1.Rows.Add()
                DataGridView1.Rows(input).Cells(0).Value = TextBox1.Text
                DataGridView1.Rows(input).Cells(1).Value = TextBox2.Text
                DataGridView1.Rows(input).Cells(2).Value = TextBox3.Text
                DataGridView1.Rows(input).Cells(3).Value = TextBox5.Text
                DataGridView1.Rows(input).Cells(4).Value = TextBox6.Text
                DataGridView1.Rows(input).Cells(5).Value = TextBox7.Text
                DataGridView1.Rows(input).Cells(6).Value = TextBox9.Text
                DataGridView1.Rows(input).Cells(7).Value = TextBox8.Text


                TextBox5.Clear()
                TextBox6.Clear()
                TextBox7.Clear()
                TextBox9.Clear()
                TextBox8.Clear()
            Catch ex As Exception
                MsgBox("Data Retur Pembelian gagal disimpan", MsgBoxStyle.Critical)
            End Try
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub


    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim myfont As New Font("arial", 15, FontStyle.Bold)
        Dim myfont1 As New Font("arial", 15, FontStyle.Regular)
        Dim myfont2 As New Font("arial", 20, FontStyle.Regular)

        tinggi += 20
        e.Graphics.DrawString("                                              PT Vehandra Anugrah Sejahtera", myfont, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("                   Perum Taman Harapan Baru Blok M2 No. 2, Satria Kota Bekasi", myfont, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("                                             No Telphone (021-88978043)", myfont, Brushes.Black, 2, tinggi)

        tinggi += 60
        e.Graphics.DrawString("                                                 NOTA RETUR PENJUALAN", myfont, Brushes.Black, 2, tinggi)
        'memeriksa jika masih ada baris tersisa

        tinggi += 60
        'DataGridView2.Item(0, DataGridView2.CurrentCell.RowIndex).Value
        e.Graphics.DrawString(" No.Nota =" & TextBox1.Text & "                                                                       Date=" & TextBox4.Text, myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString(" Kode Customer    : " & TextBox2.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Nama Customer   : " & TextBox3.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Alamat Customer  : " & TextBox10.Text, myfont1, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" No Telphone     : " & TextBox11.Text, myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)
        tinggi += 30
        e.Graphics.DrawString(" Kode          Nama Barang                       Jumlah         Harga             Keterangan", myfont1, Brushes.Black, 2, tinggi)

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)


        For baris As Integer = 0 To DataGridView1.RowCount - 2
            tinggi += 30
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(3).Value.ToString, myfont1, Brushes.Black, 4, tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(4).Value.ToString, myfont1, Brushes.Black, 150, tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(5).Value.ToString, myfont1, Brushes.Black, 400, tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(6).Value.ToString, myfont1, Brushes.Black, 570, tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(7).Value.ToString, myfont1, Brushes.Black, 650, tinggi)
        Next

        tinggi += 30
        e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------", myfont2, Brushes.Black, 2, tinggi)


        tinggi += 60
        e.Graphics.DrawString("             Hormat Kami", myfont1, Brushes.Black, 2, tinggi)

        tinggi += 100
        e.Graphics.DrawString("   PT Vehandra Anugrah Sejahtera", myfont1, Brushes.Black, 2, tinggi)
    End Sub
End Class