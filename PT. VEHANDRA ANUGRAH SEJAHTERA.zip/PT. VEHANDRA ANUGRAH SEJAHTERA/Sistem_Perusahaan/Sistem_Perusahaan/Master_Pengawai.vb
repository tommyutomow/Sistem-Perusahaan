﻿Imports System.Data.OleDb
Public Class Master_Pengawai
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Master_Pengawai_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DatabaseDataSet1.Pengawai' table. You can move, or remove it, as needed.
        tampil()
        autokode()
        Me.DataGridView2.Columns(0).Width = 70
        Me.DataGridView2.Columns(1).Width = 120
        Me.DataGridView2.Columns(2).Width = 70
        Me.DataGridView2.Columns(3).Width = 150
        Me.DataGridView2.Columns(4).Width = 70
        Me.DataGridView2.Columns(5).Width = 120

        Me.DataGridView2.Columns(0).HeaderText = "ID Pegawai"
        Me.DataGridView2.Columns(1).HeaderText = "Nama Pengawai"
        Me.DataGridView2.Columns(2).HeaderText = "Telp"
        Me.DataGridView2.Columns(3).HeaderText = "Alamat"
        Me.DataGridView2.Columns(4).HeaderText = "Username"
        Me.DataGridView2.Columns(5).HeaderText = "Posisi"


    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select ID_Pegawai,Nama_Pegawai,Telp,Alamat,Username,Posisi from Pegawai"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Pegawai")
        DataGridView2.DataSource = ds.Tables("Pegawai")

    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from Pegawai order by ID_Pegawai desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()

        If Not dr.HasRows Then
            TextBox1.Text = "PE" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("ID_Pegawai").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "PE000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "PE00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "PE0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Kode Pegawai Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Nama Pegawai Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("Telp Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf TextBox4.Text = "" Then
            MsgBox("Alamat Masih Kosong", vbCritical, "Salah")
            TextBox4.Focus()
        ElseIf TextBox5.Text = "" Then
            MsgBox("Username Masih Kosong", vbCritical, "Salah")
            TextBox5.Focus()
        ElseIf TextBox6.Text = "" Then
            MsgBox("Password Masih Kosong", vbCritical, "Salah")
            TextBox6.Focus()
        ElseIf ComboBox1.Text = "" Then
            MsgBox("Posisi Masih Kosong", vbCritical, "Salah")
            ComboBox1.Focus()
        Else
            Try
                Dim command As OleDbCommand
                query = "insert into Pegawai values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & ComboBox1.Text & "')"
                conn.Open()
                command = New OleDbCommand(query, conn)
                command.ExecuteNonQuery()
                tampil()
                MsgBox("Insert anda berhasil")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                TextBox5.Clear()
                TextBox6.Clear()
                conn.Close()
                autokode()
            Catch ex As Exception
                MsgBox("Data Pegawai gagal disimpan")
            End Try
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim command As OleDbCommand
            query = "update Pegawai set Nama_Pegawai='" & TextBox2.Text & "',Telp='" & TextBox3.Text & "', Alamat='" & TextBox4.Text & "', Username='" & TextBox5.Text & "',Pass='" & TextBox6.Text & "', Posisi='" & ComboBox1.Text & "' where ID_Pegawai = '" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            MsgBox("Update anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data gagal diupdate")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim command As OleDbCommand
            query = "delete from Pegawai where ID_Pegawai ='" & TextBox1.Text & "'"
            conn.Open()
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            tampil()
            TextBox1.ReadOnly = False
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            MsgBox("Delete anda berhasil")
            conn.Close()
            autokode()
        Catch ex As Exception
            MsgBox("Data gagal didelete")
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.ReadOnly = False
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
    End Sub


    Private Sub DataGridView2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView2.CellMouseClick
        TextBox1.ReadOnly = True
        TextBox1.Text = DataGridView2.Item(0, DataGridView2.CurrentCell.RowIndex).Value
        TextBox2.Text = DataGridView2.Item(1, DataGridView2.CurrentCell.RowIndex).Value
        TextBox3.Text = DataGridView2.Item(2, DataGridView2.CurrentCell.RowIndex).Value
        TextBox4.Text = DataGridView2.Item(3, DataGridView2.CurrentCell.RowIndex).Value
        TextBox5.Text = DataGridView2.Item(4, DataGridView2.CurrentCell.RowIndex).Value
        TextBox6.Text = DataGridView2.Item(5, DataGridView2.CurrentCell.RowIndex).Value
    End Sub
End Class