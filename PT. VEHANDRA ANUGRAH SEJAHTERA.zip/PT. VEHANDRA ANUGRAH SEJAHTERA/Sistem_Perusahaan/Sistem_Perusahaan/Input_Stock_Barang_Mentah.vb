﻿Imports System.Data.OleDb
Public Class Input_Stock_Barang_Mentah
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim rd As OleDbDataReader
    Dim dr As OleDbDataReader
    Dim query As String = ""
    Dim query1 As String = ""
    Dim query2 As String = ""
    Dim query3 As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Input_Stock_Barang_Mentah_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox2.Text = Format(Now, "dd MMMM yyyy ")
        combo()
        'If TextBox1.Text = "" Then
        '    Dim cmd As OleDbCommand
        '    query3 = "SELECT MAX(Kode_Transaksi) from StockBarangMen"
        '    conn.Open()
        '    cmd = New OleDbCommand(query3, conn)
        '    dr = cmd.ExecuteReader
        '    If dr.HasRows Then
        '        dr.Read()
        '        If dr(0) Is DBNull.Value Then
        '            TextBox1.Text = 1
        '        ElseIf dr(0) > 0 Then
        '            TextBox1.Text = dr(0) + 1
        '        End If
        '    End If
        '    conn.Close()
        'Else
        '    TextBox1.Text = ""
        'End If

        autokode()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox5.Clear()
    End Sub
    Sub combo()
        Dim cmd As OleDbCommand
        query = "SELECT Kode_BarangMentah FROM BarangMentah order by Kode_BarangMentah"
        conn.Open()
        cmd = New OleDbCommand(query, conn)
        rd = cmd.ExecuteReader
        While rd.Read()
            ComboBox1.Items.Add(rd("Kode_BarangMentah"))
        End While
        conn.Close()
    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from StockBarangMen order by Kode_Transaksi desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()


        If Not dr.HasRows Then
            TextBox1.Text = "IM" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("Kode_Transaksi").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "IM000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "IM00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "IM0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        If ComboBox1.Text = "" Then
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox6.Text = ""

        Else
            Dim dr As OleDbDataReader
            Dim com As OleDbCommand
            conn.Open()
            query = "select * from BarangMentah where Kode_BarangMentah='" & ComboBox1.Text & "'"
            com = New OleDbCommand(query, conn)
            dr = com.ExecuteReader
            dr.Read()

            If dr.HasRows Then
                TextBox3.Text = dr(1)
                TextBox6.Text = dr(2)
                TextBox4.Text = dr(3)
            End If
            conn.Close()

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Kode Transaksi Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Tanggal Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf ComboBox1.Text = "" Then
            MsgBox("Kode Barang Masih Kosong", vbCritical, "Salah")
            ComboBox1.Focus()
        ElseIf TextBox5.Text = "" Then
            MsgBox("Jumlah Barang Produksi Masih Kosong", vbCritical, "Salah")
            TextBox5.Focus()
        Else
            Try
                Dim cmd As OleDbCommand
                query1 = "SELECT * FROM BarangMentah WHERE Kode_BarangMentah='" & ComboBox1.Text & "' and Nama_Barang='" & TextBox3.Text & "'"
                conn.Open()
                cmd = New OleDbCommand(query1, conn)
                rd = cmd.ExecuteReader
                rd.Read()

                Dim stockada As Integer
                stockada = rd(2)
                Dim sisastock As Integer = stockada - TextBox5.Text
                conn.Close()

                '---------------------------------------------------------------------------------------------------------------------------------------'
                Dim cmd1 As OleDbCommand
                query2 = "update BarangMentah set Stock=" & sisastock & " WHERE Kode_BarangMentah='" & ComboBox1.Text & "' and Nama_Barang='" & TextBox3.Text & "'"
                conn.Open()
                cmd1 = New OleDbCommand(query2, conn)
                cmd1.ExecuteNonQuery()
                MsgBox("Stock Barang dari Kode = " & ComboBox1.Text & " yaitu " & sisastock, MsgBoxStyle.Information)
                conn.Close()
                '---------------------------------------------------------------------------------------------------------------------------------------'
                Dim command As OleDbCommand
                query = "insert into StockBarangMen(Kode_Transaksi,Tanggal,Kode_Barang,Nama_Barang,Jenis_Barang,Jumlah) values ( '" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')"
                conn.Open()
                command = New OleDbCommand(query, conn)
                command.ExecuteNonQuery()
                conn.Close()
                autokode()
                TextBox5.Clear()
                MsgBox("Data input stock barang mentah berhasil dikurangi", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("Data input stock barang mentah gagal disimpan", MsgBoxStyle.Critical)
            End Try
        End If
    End Sub
End Class