﻿Public Class Laporan_Penjualan

    Private Sub Laporan_Penjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim CR As New laporanpenjualan
        CrystalReportViewer1.SelectionFormula = "{Penjualan.Bulan} in '" & ComboBox1.Text & "' to '" & ComboBox2.Text & "'"
        CrystalReportViewer1.ReportSource = CR

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class