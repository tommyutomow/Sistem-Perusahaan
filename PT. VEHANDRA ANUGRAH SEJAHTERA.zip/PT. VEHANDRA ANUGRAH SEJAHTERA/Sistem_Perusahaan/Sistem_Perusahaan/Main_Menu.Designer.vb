﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterPengawaiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterCustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterItemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangMentahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangProduksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransaksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangMentahToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BarangProduksiToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PembelianToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenjualanToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanStockMentahToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanStockBarangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LaporanReturPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanReturPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterToolStripMenuItem, Me.TransaksiToolStripMenuItem, Me.ExitToolStripMenuItem, Me.ReturToolStripMenuItem, Me.LaporanToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1264, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MasterToolStripMenuItem
        '
        Me.MasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterPengawaiToolStripMenuItem, Me.MasterCustomerToolStripMenuItem, Me.MasterSupplierToolStripMenuItem, Me.MasterItemToolStripMenuItem})
        Me.MasterToolStripMenuItem.Name = "MasterToolStripMenuItem"
        Me.MasterToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.MasterToolStripMenuItem.Text = "Data Master"
        '
        'MasterPengawaiToolStripMenuItem
        '
        Me.MasterPengawaiToolStripMenuItem.Name = "MasterPengawaiToolStripMenuItem"
        Me.MasterPengawaiToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.MasterPengawaiToolStripMenuItem.Text = "Master Pengawai"
        '
        'MasterCustomerToolStripMenuItem
        '
        Me.MasterCustomerToolStripMenuItem.Name = "MasterCustomerToolStripMenuItem"
        Me.MasterCustomerToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.MasterCustomerToolStripMenuItem.Text = "Master Customer"
        '
        'MasterSupplierToolStripMenuItem
        '
        Me.MasterSupplierToolStripMenuItem.Name = "MasterSupplierToolStripMenuItem"
        Me.MasterSupplierToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.MasterSupplierToolStripMenuItem.Text = "Master Supplier"
        '
        'MasterItemToolStripMenuItem
        '
        Me.MasterItemToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BarangMentahToolStripMenuItem, Me.BarangProduksiToolStripMenuItem})
        Me.MasterItemToolStripMenuItem.Name = "MasterItemToolStripMenuItem"
        Me.MasterItemToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.MasterItemToolStripMenuItem.Text = "Master Barang"
        '
        'BarangMentahToolStripMenuItem
        '
        Me.BarangMentahToolStripMenuItem.Name = "BarangMentahToolStripMenuItem"
        Me.BarangMentahToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.BarangMentahToolStripMenuItem.Text = "Barang Mentah"
        '
        'BarangProduksiToolStripMenuItem
        '
        Me.BarangProduksiToolStripMenuItem.Name = "BarangProduksiToolStripMenuItem"
        Me.BarangProduksiToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.BarangProduksiToolStripMenuItem.Text = "Barang Produksi"
        '
        'TransaksiToolStripMenuItem
        '
        Me.TransaksiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PembelianToolStripMenuItem, Me.PenjualanToolStripMenuItem})
        Me.TransaksiToolStripMenuItem.Name = "TransaksiToolStripMenuItem"
        Me.TransaksiToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.TransaksiToolStripMenuItem.Text = "Transaksi"
        '
        'PembelianToolStripMenuItem
        '
        Me.PembelianToolStripMenuItem.Name = "PembelianToolStripMenuItem"
        Me.PembelianToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.PembelianToolStripMenuItem.Text = "Pembelian"
        '
        'PenjualanToolStripMenuItem
        '
        Me.PenjualanToolStripMenuItem.Name = "PenjualanToolStripMenuItem"
        Me.PenjualanToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.PenjualanToolStripMenuItem.Text = "Penjualan"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BarangMentahToolStripMenuItem1, Me.BarangProduksiToolStripMenuItem1})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.ExitToolStripMenuItem.Text = "Input Produksi"
        '
        'BarangMentahToolStripMenuItem1
        '
        Me.BarangMentahToolStripMenuItem1.Name = "BarangMentahToolStripMenuItem1"
        Me.BarangMentahToolStripMenuItem1.Size = New System.Drawing.Size(160, 22)
        Me.BarangMentahToolStripMenuItem1.Text = "Barang Mentah"
        '
        'BarangProduksiToolStripMenuItem1
        '
        Me.BarangProduksiToolStripMenuItem1.Name = "BarangProduksiToolStripMenuItem1"
        Me.BarangProduksiToolStripMenuItem1.Size = New System.Drawing.Size(160, 22)
        Me.BarangProduksiToolStripMenuItem1.Text = "Barang Produksi"
        '
        'ReturToolStripMenuItem
        '
        Me.ReturToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PembelianToolStripMenuItem1, Me.PenjualanToolStripMenuItem2})
        Me.ReturToolStripMenuItem.Name = "ReturToolStripMenuItem"
        Me.ReturToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ReturToolStripMenuItem.Text = "Retur"
        '
        'PembelianToolStripMenuItem1
        '
        Me.PembelianToolStripMenuItem1.Name = "PembelianToolStripMenuItem1"
        Me.PembelianToolStripMenuItem1.Size = New System.Drawing.Size(130, 22)
        Me.PembelianToolStripMenuItem1.Text = "Pembelian"
        '
        'PenjualanToolStripMenuItem2
        '
        Me.PenjualanToolStripMenuItem2.Name = "PenjualanToolStripMenuItem2"
        Me.PenjualanToolStripMenuItem2.Size = New System.Drawing.Size(130, 22)
        Me.PenjualanToolStripMenuItem2.Text = "Penjualan"
        '
        'LaporanToolStripMenuItem
        '
        Me.LaporanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanStockMentahToolStripMenuItem, Me.LaporanStockBarangToolStripMenuItem, Me.LaporanPembelianToolStripMenuItem, Me.LaporanPenjualanToolStripMenuItem, Me.LaporanReturPembelianToolStripMenuItem, Me.LaporanReturPenjualanToolStripMenuItem})
        Me.LaporanToolStripMenuItem.Name = "LaporanToolStripMenuItem"
        Me.LaporanToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.LaporanToolStripMenuItem.Text = "Laporan"
        '
        'LaporanStockMentahToolStripMenuItem
        '
        Me.LaporanStockMentahToolStripMenuItem.Name = "LaporanStockMentahToolStripMenuItem"
        Me.LaporanStockMentahToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanStockMentahToolStripMenuItem.Text = "Laporan Stock Barang Mentah"
        '
        'LaporanStockBarangToolStripMenuItem
        '
        Me.LaporanStockBarangToolStripMenuItem.Name = "LaporanStockBarangToolStripMenuItem"
        Me.LaporanStockBarangToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanStockBarangToolStripMenuItem.Text = "Laporan Stock Barang Produksi"
        '
        'LaporanPembelianToolStripMenuItem
        '
        Me.LaporanPembelianToolStripMenuItem.Name = "LaporanPembelianToolStripMenuItem"
        Me.LaporanPembelianToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanPembelianToolStripMenuItem.Text = "Laporan Pembelian"
        '
        'LaporanPenjualanToolStripMenuItem
        '
        Me.LaporanPenjualanToolStripMenuItem.Name = "LaporanPenjualanToolStripMenuItem"
        Me.LaporanPenjualanToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanPenjualanToolStripMenuItem.Text = "Laporan Penjualan"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(273, 313)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(737, 45)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "PT. VEHANDRA ANUGRAH SEJAHTERA"
        '
        'LaporanReturPembelianToolStripMenuItem
        '
        Me.LaporanReturPembelianToolStripMenuItem.Name = "LaporanReturPembelianToolStripMenuItem"
        Me.LaporanReturPembelianToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanReturPembelianToolStripMenuItem.Text = "Laporan Retur Pembelian"
        '
        'LaporanReturPenjualanToolStripMenuItem
        '
        Me.LaporanReturPenjualanToolStripMenuItem.Name = "LaporanReturPenjualanToolStripMenuItem"
        Me.LaporanReturPenjualanToolStripMenuItem.Size = New System.Drawing.Size(238, 22)
        Me.LaporanReturPenjualanToolStripMenuItem.Text = "Laporan Retur Penjualan"
        '
        'Main_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 682)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main_Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterCustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterItemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterPengawaiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangMentahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangProduksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransaksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangMentahToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PembelianToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenjualanToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanStockBarangToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BarangProduksiToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LaporanStockMentahToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanReturPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanReturPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
