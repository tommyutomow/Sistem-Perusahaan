﻿Public Class Laporan_Retur_Penjualan

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim CR As New LaporanPembelian
        CrystalReportViewer1.SelectionFormula = "{ReturPenjualan.Bulan} in '" & ComboBox1.Text & "' to '" & ComboBox2.Text & "'"
        CrystalReportViewer1.ReportSource = CR
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class