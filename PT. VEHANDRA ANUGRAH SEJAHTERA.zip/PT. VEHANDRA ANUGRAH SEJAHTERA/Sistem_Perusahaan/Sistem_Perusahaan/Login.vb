﻿Imports System.Data.OleDb
Public Class Login
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim rd As OleDbDataReader
    Dim cmd As OleDbCommand
    Dim ds As New DataSet()
    Dim query As String = ""
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        conn.Open()

        query = "SELECT * FROM Pegawai WHERE Username='" & TextBox1.Text & "' and Pass='" & TextBox2.Text & "'"
        cmd = New OleDbCommand(query, conn)
        rd = cmd.ExecuteReader
        rd.Read()
        If rd.HasRows Then
            If rd(6) = "Owner" Then
                Me.Visible = False
                Main_Menu.Show()
                MsgBox("Login Sukses, Selamat Datang!")
            ElseIf rd(6) = "Pengawai" Then
                Me.Visible = False
                Main_Menu_Pegawai.Show()
                MsgBox("Login Sukses, Selamat Datang!")
            ElseIf rd(6) = "Produksi" Then
                Me.Visible = False
                Main_Menu_Produksi.Show()
                MsgBox("Login Sukses, Selamat Datang!")
            End If
        Else
            MsgBox("Username dan Password Anda Salah, Silakan Ulang!")
            TextBox1.Clear()
            TextBox2.Clear()
        End If
        conn.Close()
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class