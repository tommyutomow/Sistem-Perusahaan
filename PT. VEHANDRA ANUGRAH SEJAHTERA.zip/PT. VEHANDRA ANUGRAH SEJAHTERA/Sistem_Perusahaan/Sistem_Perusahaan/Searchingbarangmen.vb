﻿Imports System.Data.OleDb
Public Class Searchingbarangmen
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ReturPembelian.TextBox5.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        ReturPembelian.TextBox6.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        ReturPembelian.TextBox7.Text = DataGridView1.Item(4, DataGridView1.CurrentCell.RowIndex).Value
        Me.Close()
    End Sub

    Private Sub Searchingbarangmen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tampil()
    End Sub
    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from BarangMentah"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "BarangMentah")
        DataGridView1.DataSource = ds.Tables("BarangMentah")

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class