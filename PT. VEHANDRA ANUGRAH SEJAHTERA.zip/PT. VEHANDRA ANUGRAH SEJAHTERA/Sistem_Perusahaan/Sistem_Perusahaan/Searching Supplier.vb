﻿Imports System.Data.OleDb
Public Class Searching_Supplier
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        ds = New DataSet
        ds.Clear()
        query = "select * from Supplier where Nama_Perusahaan like '%" & TextBox1.Text & "%'"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Item")
        DataGridView1.DataSource = ds.Tables("Item")
    End Sub

    Private Sub Searching_Supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tampil()
    End Sub

    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from Supplier"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Supplier")
        DataGridView1.DataSource = ds.Tables("Supplier")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Pembelian.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Pembelian.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Pembelian.TextBox12.Text = DataGridView1.Item(2, DataGridView1.CurrentCell.RowIndex).Value
        Pembelian.TextBox4.Text = DataGridView1.Item(3, DataGridView1.CurrentCell.RowIndex).Value

        ReturPembelian.TextBox2.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        ReturPembelian.TextBox3.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub
End Class