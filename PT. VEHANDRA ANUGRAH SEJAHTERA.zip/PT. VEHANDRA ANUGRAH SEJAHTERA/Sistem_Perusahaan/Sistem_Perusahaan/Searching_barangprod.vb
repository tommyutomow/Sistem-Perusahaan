﻿Imports System.Data.OleDb
Public Class Searching_barangprod
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim query As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub Searching_barangprod_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tampil()
    End Sub
    Sub tampil()
        ds = New DataSet
        ds.Clear()
        query = "select * from BarangProduksi"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "BarangProduksi")
        DataGridView1.DataSource = ds.Tables("BarangProduksi")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Retur_Penjualan.TextBox5.Text = DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox6.Text = DataGridView1.Item(1, DataGridView1.CurrentCell.RowIndex).Value
        Retur_Penjualan.TextBox7.Text = DataGridView1.Item(4, DataGridView1.CurrentCell.RowIndex).Value
        Me.Close()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        ds = New DataSet
        ds.Clear()
        query = "select * from BarangProduksi where Nama_Barang like '%" & TextBox1.Text & "%'"
        oledbpenghubung = New OleDbDataAdapter(query, conn)
        oledbpenghubung.Fill(ds, "Item")
        DataGridView1.DataSource = ds.Tables("Item")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class