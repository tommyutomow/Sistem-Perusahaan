﻿Imports System.Data.OleDb
Public Class ReturPembelian
    Dim conn As OleDbConnection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb")
    Dim oledbpenghubung As OleDbDataAdapter
    Dim ds As New DataSet()
    Dim rd As OleDbDataReader
    Dim dr As OleDbDataReader
    Dim query As String = ""
    Dim query1 As String = ""
    Dim query2 As String = ""
    Dim query3 As String = ""
    Dim constring As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\PT. VEHANDRA ANUGRAH SEJAHTERA\Database.mdb"

    Private Sub ReturPembelian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox4.Text = Format(Now, "dd MMMM yyyy ")
        TextBox16.Text = Format(Now, "MMMM")
        autokode()
        'Dim cmd As OleDbCommand
        'query3 = "SELECT MAX(No_Retur) from ReturPembelian"
        'conn.Open()
        'cmd = New OleDbCommand(query3, conn)
        'dr = cmd.ExecuteReader
        'If dr.HasRows Then
        '    dr.Read()
        '    If dr(0) Is DBNull.Value Then
        '        TextBox1.Text = 1
        '    ElseIf dr(0) > 0 Then
        '        TextBox1.Text = dr(0) + 1
        '    End If
        'End If
        'conn.Close()
    End Sub
    Sub autokode()
        TextBox1.Enabled = False
        Dim cmd As OleDb.OleDbCommand
        Dim dr As OleDbDataReader
        conn.Open()
        cmd = New OleDbCommand("select * from ReturPembelian order by No_Retur desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()


        If Not dr.HasRows Then
            TextBox1.Text = "RB" + "0001"
        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Mid(dr.Item("No_Retur").ToString, 4, 3)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "RB000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "RB00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "RB0" & TextBox1.Text & ""
            End If
        End If
        TextBox2.Focus()
        conn.Close()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Searching_Supplier.Show()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Searchingbarangmen.Show()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox9.Clear()
        TextBox8.Clear()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If TextBox1.Text = "" Then
            MsgBox("No Retur Masih Kosong", vbCritical, "Salah")
            TextBox1.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("Kode Supplier Masih Kosong", vbCritical, "Salah")
            TextBox2.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("Nama Supplier Masih Kosong", vbCritical, "Salah")
            TextBox3.Focus()
        ElseIf TextBox5.Text = "" Then
            MsgBox("KodeBarang Masih Kosong", vbCritical, "Salah")
            TextBox5.Focus()
        ElseIf TextBox6.Text = "" Then
            MsgBox("NamaBarang Masih Kosong", vbCritical, "Salah")
            TextBox6.Focus()
        ElseIf TextBox7.Text = "" Then
            MsgBox("Harga Masih Kosong", vbCritical, "Salah")
            TextBox7.Focus()
        ElseIf TextBox9.Text = "" Then
            MsgBox("Jumlah Barang Masih Kosong", vbCritical, "Salah")
            TextBox9.Focus()
        ElseIf TextBox8.Text = "" Then
            MsgBox("Keterangan Masih Kosong", vbCritical, "Salah")
            TextBox8.Focus()
        Else
            'Try

            Dim cmd As OleDbCommand
            query1 = "SELECT * FROM BarangMentah WHERE Kode_BarangMentah='" & TextBox5.Text & "' and Nama_Barang='" & TextBox6.Text & "'"
            conn.Open()
            cmd = New OleDbCommand(query1, conn)
            rd = cmd.ExecuteReader
            rd.Read()
            Dim stockada As Integer
            stockada = rd(2)
            Dim sisastock As Integer = stockada - TextBox9.Text
            conn.Close()
            '---------------------------------------------------------------------------------------------------------------------------------------'
            Dim cmd1 As OleDbCommand
            query2 = "update BarangMentah set Stock=" & sisastock & " WHERE Kode_BarangMentah='" & TextBox5.Text & "' and Nama_Barang='" & TextBox6.Text & "'"
            conn.Open()
            cmd1 = New OleDbCommand(query2, conn)
            cmd1.ExecuteNonQuery()
            MsgBox("Sisa stock setelah retur pembelian dengan Kode barang = " & TextBox5.Text & " yaitu " & sisastock, MsgBoxStyle.Information)
            conn.Close()

            '---------------------------------------------------------------------------------------------------------------------------------------'
            Dim command As OleDbCommand
            conn.Open()
            query = "insert into ReturPembelian(No_Retur,Tanggal,Kode_Supplier,Nama_Supplier,Kode_Barang,Nama_Barang,Harga,Jumlah,Keterangan,Bulan) values ( '" & TextBox1.Text & "','" & TextBox4.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "'," & TextBox7.Text & "," & TextBox9.Text & ",'" & TextBox8.Text & "','" & TextBox16.Text & "')"
            command = New OleDbCommand(query, conn)
            command.ExecuteNonQuery()
            conn.Close()
            autokode()
            Dim input As Integer = DataGridView1.Rows.Add()
            DataGridView1.Rows(input).Cells(0).Value = TextBox1.Text
            DataGridView1.Rows(input).Cells(1).Value = TextBox2.Text
            DataGridView1.Rows(input).Cells(2).Value = TextBox3.Text
            DataGridView1.Rows(input).Cells(3).Value = TextBox5.Text
            DataGridView1.Rows(input).Cells(4).Value = TextBox6.Text
            DataGridView1.Rows(input).Cells(5).Value = TextBox7.Text
            DataGridView1.Rows(input).Cells(6).Value = TextBox9.Text
            DataGridView1.Rows(input).Cells(7).Value = TextBox8.Text


            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            TextBox9.Clear()
            TextBox8.Clear()
            'Catch ex As Exception
            'MsgBox("Data Retur Pembelian gagal disimpan", MsgBoxStyle.Critical)
            'End Try
        End If
    End Sub
End Class